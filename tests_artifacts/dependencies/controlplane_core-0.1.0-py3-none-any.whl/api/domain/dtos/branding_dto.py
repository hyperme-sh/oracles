from typing import Optional

from pydantic import BaseModel, Field

from api.domain.entities.branding import ContactInfo, LogoType, ThemeConfig


class BrandingDto(BaseModel):
    id: str
    logo_type: Optional[LogoType] = None
    contact_info: Optional[ContactInfo] = None
    theme_config: ThemeConfig = Field(default_factory=ThemeConfig)
    tenant_id: str
    created_at: str
    updated_at: str
    app_name: str = "SaaS Org"
    favicon_url: Optional[str] = None
    logo_url: Optional[str] = None

   
    
class IdentityDto(BaseModel):
    app_name: str = "SaaS Org"

class UpdateBrandingDto(BaseModel):
    identity: Optional[IdentityDto] = None
    contact_info: Optional[ContactInfo] = None
    theme_config: Optional[ThemeConfig] = None
    tenant_id: Optional[str] = None
    logo_url: Optional[str] = None
    logo_type: Optional[LogoType] = None